<?php

/**
 * Studi Kasus :
 * 1. Terdapat sebuah variabel a dan b. cobalah tukar nilai variabel a dan b!
 * 2. Tampilkan hasil perhitungan dari rumus luas segitiga!
 * 3. Tampilkan rumus luas lingkaran dan tampilkan hasil perhitungannya jika r = 14
 * 4. Tampilkan data berikut dalam sebuah html yang telah diberikan dengan ketentuan berikut :
 *      - Render data nama dan role pada section our team
 *      - Render harga paket pada section pricing dimana paket Basic mempunyai harga Rp. 50000, Harga 
 *        paket pro 2x harga paket basic, harga paket premium adalah hasil dari harga paket basic
 *        ditambah harga paket pro
 *      - Render data pada section Contact US
 */